package jag_group_1.spring_jdbc_1;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//    	DriverManagerDataSource dmds=new DriverManagerDataSource();
//    	dmds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
//    	dmds.setUrl("jdbc:oracle:thin:@localhost:1522:xe");
//    	dmds.setUsername("sys as sysdba");
//    	dmds.setPassword("password");
    	
    	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
    	DriverManagerDataSource dmds= (DriverManagerDataSource) ctx.getBean("dmds");
    	
    	JdbcTemplate jt=(JdbcTemplate) ctx.getBean("jt");
//    	JdbcTemplate jt=new JdbcTemplate();
//    	jt.setDataSource(dmds);				//setter injection
    	
    	int no = jt.update("UPDATE Vehicle SET NAME='Kwid', TYPE='Hatch Back', COMPANY='Renault' WHERE ID=148");
    	System.out.println(no+" row(s) affected");
    	
    	List<Vehicle> result = jt.query("SELECT * FROM Vehicle WHERE id=?",new VehicleRowMapper(),147);
    	System.out.println(result.get(0));
    	System.out.println("done");
    	List<Vehicle> vehicles = jt.query("SELECT * FROM Vehicle WHERE id=147", new VehicleRowMapper());
    	for(Vehicle v: vehicles)
    		System.out.println(v);
    	System.out.println( "Hello World!" );
    }
}
